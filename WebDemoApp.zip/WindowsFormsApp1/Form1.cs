﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessObjectPresenters.Interfaces;
using BusinessObjectPresenters;
namespace WindowsFormsApp1
{
    public partial class Form1 : Form, IInscribed
    {
        InscribedPresenter pres;
        public Form1()
        {
            InitializeComponent();
        }

        public string DocumentId { get =>this.tDocumentId.Text; set => this.tDocumentId.Text = value; }
        public string FirstName { get => this.tFirstName.Text; set => this.tFirstName.Text = value; }
        public string LastName { get => this.tLastName.Text; set => this.tLastName.Text = value; }
        public string Gener { get => this.tGener.Text; set => this.tGener.Text = value; }
        public string Phone { get => this.tPhone.Text; set => this.tPhone.Text = value; }
        public string Address { get => this.tAddress.Text; set => this.tAddress.Text = value; }
        public bool IsActive { get => this.checkBox1.Checked; set => this.checkBox1.Checked = value; }
        public bool IsRegister { get => this.checkBox2.Checked; set => this.checkBox2.Checked = value; }

        public void Clear()
        {
            this.tDocumentId.Text = string.Empty;
            this.tFirstName.Text = string.Empty;
            this.tLastName.Text = string.Empty;
            this.tGener.Text = string.Empty;
            this.tPhone.Text = string.Empty;
            this.tAddress.Text = string.Empty;
            this.checkBox1.Checked = false;
            this.checkBox2.Checked = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pres = new InscribedPresenter(this);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pres.Find();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pres.Save();
        }
    }
}
