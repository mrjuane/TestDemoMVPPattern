﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tDocumentId = new System.Windows.Forms.TextBox();
            this.tFirstName = new System.Windows.Forms.TextBox();
            this.tLastName = new System.Windows.Forms.TextBox();
            this.tGener = new System.Windows.Forms.TextBox();
            this.tPhone = new System.Windows.Forms.TextBox();
            this.tAddress = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "DocumentId";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 267);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(134, 202);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(78, 21);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "IsActive";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(134, 229);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(214, 21);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Text = "Esta Registrado en el partido";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(12, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "FirstName";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(12, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "LastName";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(12, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Gener";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(12, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Phone";
            // 
            // tDocumentId
            // 
            this.tDocumentId.Location = new System.Drawing.Point(134, 13);
            this.tDocumentId.Name = "tDocumentId";
            this.tDocumentId.Size = new System.Drawing.Size(381, 22);
            this.tDocumentId.TabIndex = 8;
            // 
            // tFirstName
            // 
            this.tFirstName.Location = new System.Drawing.Point(134, 46);
            this.tFirstName.Name = "tFirstName";
            this.tFirstName.Size = new System.Drawing.Size(381, 22);
            this.tFirstName.TabIndex = 9;
            // 
            // tLastName
            // 
            this.tLastName.Location = new System.Drawing.Point(134, 76);
            this.tLastName.Name = "tLastName";
            this.tLastName.Size = new System.Drawing.Size(381, 22);
            this.tLastName.TabIndex = 10;
            // 
            // tGener
            // 
            this.tGener.Location = new System.Drawing.Point(134, 101);
            this.tGener.Name = "tGener";
            this.tGener.Size = new System.Drawing.Size(381, 22);
            this.tGener.TabIndex = 11;
            // 
            // tPhone
            // 
            this.tPhone.Location = new System.Drawing.Point(134, 129);
            this.tPhone.Name = "tPhone";
            this.tPhone.Size = new System.Drawing.Size(381, 22);
            this.tPhone.TabIndex = 12;
            // 
            // tAddress
            // 
            this.tAddress.Location = new System.Drawing.Point(134, 158);
            this.tAddress.Name = "tAddress";
            this.tAddress.Size = new System.Drawing.Size(381, 22);
            this.tAddress.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(12, 153);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "Address";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(134, 267);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 559);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tAddress);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tPhone);
            this.Controls.Add(this.tGener);
            this.Controls.Add(this.tLastName);
            this.Controls.Add(this.tFirstName);
            this.Controls.Add(this.tDocumentId);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tDocumentId;
        private System.Windows.Forms.TextBox tFirstName;
        private System.Windows.Forms.TextBox tLastName;
        private System.Windows.Forms.TextBox tGener;
        private System.Windows.Forms.TextBox tPhone;
        private System.Windows.Forms.TextBox tAddress;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button2;
    }
}

