﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjectPresenters.Interfaces
{
    /// <summary>
    /// interface con funcion de view
    /// </summary>
    public interface IInscribed
    {
        string DocumentId { get; set; }
        string FirstName { get; set; }
        string LastName { get; set; }
        string Gener { get; set; }
        string Phone { get; set; }
        string Address { get; set; }
        bool IsActive { get; set; }
        bool IsRegister { get; set; }
        void Clear();
    }
}
