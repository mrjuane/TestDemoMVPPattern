﻿namespace BusinessObjectPresenters
{
   public interface IPresenter
    {
        bool Delete();
        bool Find();
        void Gather();
        void Scatter();
        bool Save();
    }
}