﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessObjectPresenters.Interfaces;
using BusinessObject;
using BusinessObject.POCO;

namespace BusinessObjectPresenters
{
    public class InscribedPresenter : IPresenter
    {
        InscribedsRepository inscribedsRepository = new InscribedsRepository();
        Inscribed inscribed = new Inscribed();

        CiticentsRepository citicentRepository = new CiticentsRepository();
        Citicent citicent = new Citicent();

        //custome view
        IInscribed _View;
        
        public InscribedPresenter(IInscribed view)
        {
            this._View = view;
        }

        public void SetPresenter(IInscribed view)
        {
            this._View = view;
        }
        
        public bool Delete()
        {
            var result = inscribedsRepository.Delete(this._View.DocumentId);
            if (result)
            {
                this._View.Clear();
            }
            return result;
        }

        public bool Find()
        {
            bool result = false;

            this.inscribed = inscribedsRepository.Find(this._View.DocumentId);
            result = this.inscribed != null;

            if(!result)
            {
                citicent = citicentRepository.Find(this._View.DocumentId);
                result = citicent != null;
            }
            Scatter();

            return result;
        }

        public void Gather()
        {
            this.inscribed = new Inscribed()
            {
                DocumentId = this._View.DocumentId,
                FirstName = this._View.FirstName,
                LastName = this._View.LastName,
                Gener = this._View.Gener,
                Phone = this._View.Phone,
                Address = this._View.Address,
                IsActive = this._View.IsActive
            };
        }

        public void Scatter()
        {
            if (this.inscribed != null)
            {
                this._View.DocumentId = this.inscribed.DocumentId;
                this._View.FirstName = this.inscribed.FirstName;
                this._View.LastName = this.inscribed.LastName;
                this._View.Gener = this.inscribed.Gener;
                this._View.Phone = this.inscribed.Phone;
                this._View.Address = this.inscribed.Address;
                this._View.IsActive = this.inscribed.IsActive;
                this._View.IsRegister = true;
                return;
            }
            else if(this.citicent != null)
            {
                this._View.DocumentId = this.citicent.DocumentId;
                this._View.FirstName = this.citicent.FirstName;
                this._View.LastName = this.citicent.LastName;
                this._View.Gener = this.citicent.Gener;
                this._View.Phone = this.citicent.Phone;
                this._View.Address = this.citicent.Address;
                this._View.IsActive = false;
                this._View.IsRegister = false;
            }
        }

        public bool Save()
        {
            this.Gather();
            var result = this.inscribedsRepository.Add(inscribed);
            if (result)
            {
                this._View.Clear();
            }
            return result;
        }
        
    }
}
