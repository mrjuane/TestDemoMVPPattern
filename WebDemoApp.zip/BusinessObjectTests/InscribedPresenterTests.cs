﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BusinessObjectPresenters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessObjectPresenters.Interfaces;

namespace BusinessObject.Tests
{
    [TestClass()]
    public class InscribedPresenterTests : IInscribed
    {
        private string _DocumentId = "00145678954";//"00145678952";//"00145678954";
        private string _FirstName = "Pedro";
        private string _LastName = "alvarado";
        private string _Phone = "8298885555";
        private string _Address = "mayo guatapanal";
        private string _Gener = "M";
        private bool _IsActive = true;
        private bool _IsRegister = false;

        public string DocumentId { get => _DocumentId; set => _DocumentId = value; }
        public string FirstName { get => _FirstName; set => _FirstName = value; }
        public string LastName { get => _LastName; set => _LastName = value; }
        public string Gener { get => _Gener; set => _Gener = value; }
        public string Phone { get => _Phone; set => _Phone = value; }
        public string Address { get => _Address; set => _Address = value; }
        public bool IsActive { get => _IsActive; set => _IsActive = value; }
        public bool IsRegister { get => _IsRegister; set => _IsRegister = value; }

        public void Clear()
        {
            throw new NotImplementedException();
        }

        [TestMethod()]
        public void FindTest()
        {
            InscribedPresenter presenter = new InscribedPresenter(this);
            Assert.IsTrue(presenter.Find());
            Assert.IsTrue(this.IsRegister);
        }
    }
}