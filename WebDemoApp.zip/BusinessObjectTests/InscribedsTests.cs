﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BusinessObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject.Tests
{
    [TestClass()]
    public class InscribedsTests
    {
        [TestMethod()]
        public void AddTest()
        {
            InscribedsRepository inscribeds = new InscribedsRepository();

            Assert.IsTrue(inscribeds.Add(new POCO.Inscribed()
            {
                DocumentId = "00145678954",
                Address = "mayo guatapanal",
                FirstName = "Pedro",
                LastName = "alvarado",
                Gener = "M",
                Phone = "8298885555",
                IsActive = true
            })
           );
        }
    }
}