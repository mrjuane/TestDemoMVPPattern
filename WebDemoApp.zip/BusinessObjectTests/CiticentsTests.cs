﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BusinessObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject.Tests
{
    [TestClass()]
    public class CiticentsTests
    {
        [TestMethod()]
        public void AddTest()
        {
            CiticentsRepository citicent = new CiticentsRepository();

            Assert.IsTrue(citicent.Add(new POCO.Citicent() {
            DocumentId = "00145678954",
            Address = "mayo guatapanal",
            FirstName = "Pedro",
            LastName = "alvarado",
            Gener = "M",
            Phone = "8298885555"
            })
           );
        }

        [TestMethod()]
        public void AddTest1()
        {
            CiticentsRepository citicent = new CiticentsRepository();

            Assert.IsTrue(citicent.Add(new POCO.Citicent()
            {
                DocumentId = "00145678952",
                Address = "Esperanza",
                FirstName = "Maria",
                LastName = "Pena",
                Gener = "F",
                Phone = "8298770000"
            })
          );
        }

        [TestMethod()]
        public void AddTest2()
        {
            CiticentsRepository citicent = new CiticentsRepository();

            Assert.IsTrue(citicent.Add(new POCO.Citicent()
            {
                DocumentId = "00145678959",
                Address = "las canitas",
                FirstName = "alejandro",
                LastName = "ramirez",
                Gener = "M",
                Phone = "8295225000"
            })
          );
        }

    }
}