﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject.Querys
{
    internal class CiticentQuerys
    {
        public string Search { get
            {
                return @"SELECT [DocumentId]
                                ,[FirstName]
                                ,[LastName]
                                ,[Gener]
                                ,[Phone]
                                ,[Address]
            FROM [DtInscribed].[dbo].[Citicents] where DocumentId = @DocumentId";
            } 
                
                }

        public string Insert {
            get
            {
                return @"INSERT INTO [dbo].[Citicents]
                                       ([DocumentId]
                                       ,[FirstName]
                                       ,[LastName]
                                       ,[Gener]
                                       ,[Phone]
                                       ,[Address])
                                 VALUES
                                       ( @DocumentId
                                       , @FirstName
                                       , @LastName
                                       , @Gener
                                       , @Phone 
                                       , @Address)";
            }
        }

        public string Delete {
            get
            {
                return @"DELETE FROM [dbo].[Citicents] WHERE DocumentId = @DocumentId";
            }
        }

        public string Update {
            get
            {
                return @"UPDATE [dbo].[Citicents]
                           SET
                               [FirstName] = @FirstName
                              ,[LastName] = @LastName
                              ,[Gener] = @Gener
                              ,[Phone] = @Phone
                              ,[Address] = @Address
                         WHERE [DocumentId] = @DocumentId";
            }
        }

    }
}
