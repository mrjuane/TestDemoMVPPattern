﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject.Querys
{
   internal class InscribedQuerys
    {
        public string Search
        {
            get
            {
                return @"SELECT [DocumentId]
                              ,[FirstName]
                              ,[LastName]
                              ,[Gener]
                              ,[Phone]
                              ,[Address]
                              ,[IsActive]
            FROM [DtInscribed].[dbo].[Inscribed] where DocumentId = @DocumentId";
            }
        }

        public string Insert
        {
            get
            {
                return @"INSERT INTO [dbo].[Inscribed]
                                       ([DocumentId]
                                      ,[FirstName]
                                      ,[LastName]
                                      ,[Gener]
                                      ,[Phone]
                                      ,[Address]
                                      ,[IsActive])
                                 VALUES
                                       ( @DocumentId
                                       , @FirstName
                                       , @LastName
                                       , @Gener
                                       , @Phone 
                                       , @Address
                                       , @IsActive)";
            }
        }

        public string Delete
        {
            get
            {
                return @"DELETE FROM [dbo].[Inscribed] WHERE DocumentId = @DocumentId";
            }
        }

        public string Update
        {
            get
            {
                return @"UPDATE [dbo].[Inscribed]
                           SET
                               [FirstName] = @FirstName
                              ,[LastName] = @LastName
                              ,[Gener] = @Gener
                              ,[Phone] = @Phone
                              ,[Address] = @Address
                              ,[IsActive] =@IsActive
                         WHERE [DocumentId] = @DocumentId";
            }
        }
    }
}
