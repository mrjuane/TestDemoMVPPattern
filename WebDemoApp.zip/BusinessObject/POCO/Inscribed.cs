﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject.POCO
{
   public class Inscribed
    {
      private string _DocumentId;
      private string _FirstName;
      private string _LastName;
      private string _Gener;
      private string _Phone;
      private string _Address;
      private bool _IsActive;

        public string DocumentId { get => _DocumentId; set => _DocumentId = value; }
        public string FirstName { get => _FirstName; set => _FirstName = value; }
        public string LastName { get => _LastName; set => _LastName = value; }
        public string Gener { get => _Gener; set => _Gener = value; }
        public string Phone { get => _Phone; set => _Phone = value; }
        public string Address { get => _Address; set => _Address = value; }
        public bool IsActive { get => _IsActive; set => _IsActive = value; }
    }
}
