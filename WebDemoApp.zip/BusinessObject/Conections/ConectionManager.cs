﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
namespace BusinessObject.Conections
{
    internal class ConectionManager: IDisposable
    {
        private bool isDisposed = false;
        private SqlConnection _conn;
        public SqlConnection Conection { get { return this._conn; } }

        public ConectionManager()
        {
            var conString = ConfigurationManager.ConnectionStrings["ConnDtInscribed"].ConnectionString;
            _conn = new SqlConnection(conString);
        }

        public void Open() {
            if (this._conn.State != System.Data.ConnectionState.Open)
            {
                this._conn.Open();
            }
        }

        public void Close() {
            if (this._conn.State != System.Data.ConnectionState.Closed)
            {
                this._conn.Close();
            }
        }

        public void Dispose()
        {
            //   throw new NotImplementedException();
            if (!this.isDisposed)
            {
                if (_conn.State == System.Data.ConnectionState.Open )
                {
                    _conn.Close();
                    _conn.Dispose();
                    GC.SuppressFinalize(_conn);
                    this.isDisposed = true;
                }
            }
        }
    }
}
