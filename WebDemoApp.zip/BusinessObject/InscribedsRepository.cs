﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessObject.POCO;
using BusinessObject.Querys;

namespace BusinessObject
{
    public class InscribedsRepository : IRepository<POCO.Inscribed>
    {
        bool result = false;

        public bool Add(Inscribed entity)
        {
            if (this.Find(entity.DocumentId) != null)
            {
                return this.Update(entity);
            }
            else
            {
                return this.Save(entity);
            }
        }

        public bool Delete(params object[] ids)
        {
            result = false;
            using (var con = new Conections.ConectionManager())
            {
                var querys = new InscribedQuerys();
                var cmd = new SqlCommand(querys.Delete, con.Conection);
                cmd.Parameters.Add("@DocumentId", SqlDbType.NVarChar, 50).Value = ids[0].ToString();
                con.Open();
                result = cmd.ExecuteNonQuery() > 0;
            }
            return result;
        }

        public Inscribed Find(params object[] ids)
        {
            Inscribed inscribed = null;
            using (var con = new Conections.ConectionManager())
            {
                var querys = new InscribedQuerys();
                var cmd = new SqlCommand(querys.Search, con.Conection);
                cmd.Parameters.Add("@DocumentId", SqlDbType.NVarChar, 50).Value = ids[0].ToString();
                con.Open();
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (inscribed == null)
                    {
                        inscribed = new Inscribed()
                        {
                            DocumentId = reader.GetString(reader.GetOrdinal("DocumentId")),
                            FirstName = reader.GetString(reader.GetOrdinal("FirstName")),
                            LastName = reader.GetString(reader.GetOrdinal("LastName")),
                            Gener = reader.GetString(reader.GetOrdinal("Gener")),
                            Phone = reader.GetString(reader.GetOrdinal("Phone")),
                            Address = reader.GetString(reader.GetOrdinal("Address")),
                            IsActive = reader.GetBoolean(reader.GetOrdinal("IsActive"))
                        };
                    }
                }
                return inscribed;
            }
        }

        public bool Save(Inscribed entity)
        {
            result = false;
            using (var con = new Conections.ConectionManager())
            {
                var querys = new InscribedQuerys();
                var cmd = new SqlCommand(querys.Insert, con.Conection);
                cmd.Parameters.Add("@DocumentId", SqlDbType.NVarChar, 50).Value = entity.DocumentId;
                cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50).Value = entity.FirstName;
                cmd.Parameters.Add("@LastName", SqlDbType.NVarChar, 50).Value = entity.LastName;
                cmd.Parameters.Add("@Gener", SqlDbType.NChar, 1).Value = entity.Gener;
                cmd.Parameters.Add("@Phone", SqlDbType.NVarChar, 10).Value = entity.Phone;
                cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 250).Value = entity.Address;
                cmd.Parameters.Add("@IsActive", SqlDbType.Bit).Value = entity.IsActive;

                con.Open();
                result = cmd.ExecuteNonQuery() > 0;
            }
            return result;
        }

        public bool Update(Inscribed entity)
        {
            result = false;
            using (var con = new Conections.ConectionManager())
            {
                var querys = new InscribedQuerys();
                var cmd = new SqlCommand(querys.Update, con.Conection);
                cmd.Parameters.Add("@DocumentId", SqlDbType.NVarChar, 50).Value = entity.DocumentId;
                cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50).Value = entity.FirstName;
                cmd.Parameters.Add("@LastName", SqlDbType.NVarChar, 50).Value = entity.LastName;
                cmd.Parameters.Add("@Gener", SqlDbType.NChar, 1).Value = entity.Gener;
                cmd.Parameters.Add("@Phone", SqlDbType.NVarChar, 10).Value = entity.Phone;
                cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 250).Value = entity.Address;
                cmd.Parameters.Add("@IsActive", SqlDbType.Bit).Value = entity.IsActive;
                con.Open();
                result = cmd.ExecuteNonQuery() > 0;
            }
            return result;
        }
    }
}
