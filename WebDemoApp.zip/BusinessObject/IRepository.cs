﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObject
{
    interface IRepository<T>
    {
        bool Save(T entity);
        bool Add(T entity);
        bool Update(T entity);
        bool Delete(params object[] ids);
        T Find(params object[] ids);
    }
}
